# Side-by-Side: Standardization Comparison

## Original glmnet.f Standardization

```fortran
!============================================
! glmnet.f standardization (elnetu, line 813+)
!============================================

! Input: x(no,ni), y(no), w(no)
! isd = 1 (standardize), intr = 1 (intercept)

! Step 1: Normalize weights
sw = sum(w)
w = w / sw              ! weights now sum to 1.0

! Step 2: Square root transform
v = sqrt(w)             ! v(i) = sqrt(w(i))

! Step 3: Process each predictor
do j = 1, ni
  ! Compute weighted mean
  xm(j) = dot_product(w, x(:,j))
  
  ! Center and multiply by sqrt(w)
  x(:,j) = v * (x(:,j) - xm(j))
  
  ! Compute sum of squares (after weighting)
  xv(j) = dot_product(x(:,j), x(:,j))
  
  ! Compute standard deviation
  xs(j) = sqrt(xv(j))
  
  ! Standardize (divide by std dev)
  x(:,j) = x(:,j) / xs(j)
end do

! Step 4: Set xv to 1.0 (CRITICAL!)
xv(:) = 1.0             ! All predictors have unit "variance"

! Step 5: Process response
ym = dot_product(w, y)
y = v * (y - ym)
ys = sqrt(dot_product(y, y))
y = y / ys

! Result:
! - x is centered, weighted, and standardized
! - y is centered, weighted, and standardized  
! - xv(:) = 1.0 for all predictors
! - weights sum to 1.0
```

## Our Module's Standardization

```fortran
!============================================
! fit_elasticnet_mo standardization (line 257+)
!============================================

! Input: x(no,ni), y(no), w(no)
! isd = .true. (standardize), intr = .true. (intercept)

sw = sum(w)

! Process each predictor
do j = 1, ni
  ! Compute weighted mean
  wmean = sum(w * x(:,j)) / sw
  x_mean(j) = wmean
  
  ! Compute weighted variance
  wvar = 0.0
  do i = 1, no
    temp = x(i,j) - wmean
    wvar = wvar + w(i) * temp * temp
  end do
  wvar = wvar / sw
  
  ! Compute weighted standard deviation
  x_std_dev(j) = sqrt(wvar)
  
  ! Standardize directly
  do i = 1, no
    x_std(i,j) = (x(i,j) - wmean) / x_std_dev(j)
  end do
end do

! Process response  
y_mean = sum(w * y) / sw
do i = 1, no
  y_cen(i) = y(i) - y_mean
end do

! In coordinate descent (line 197):
do m = 1, ni
  xv(m) = sum(w * x_std(:,m)**2)  ! NOT 1.0!
end do

! Result:
! - x is centered and standardized (standard way)
! - y is centered (not standardized)
! - xv(m) ≈ sum(w) for each predictor (e.g., 10.0 in our test)
! - weights unchanged (still [1,2,3,4])
```

## Key Differences Table

| Aspect | glmnet.f | Our Module | Impact |
|--------|----------|------------|--------|
| Weight normalization | w = w/sum(w) | No normalization | Different weighting |
| Weight transform | v = sqrt(w) | Not used | Different scaling |
| X centering | x = v*(x-mean) | x = (x-mean) | Different |
| X standardization | Two-step | One-step | Different |
| xv value after std | xv = 1.0 | xv ≈ sum(w) | **CRITICAL** |
| Y standardization | y = (v*(y-mean))/std | y = y-mean | Different |

## Numerical Example (Our Test Data)

**Weights**: w = [1, 2, 3, 4], sum(w) = 10

### glmnet.f Path
```
w normalized: [0.1, 0.2, 0.3, 0.4]
v = sqrt(w):  [0.316, 0.447, 0.548, 0.632]
... (standardization steps) ...
xv = 1.0  ← Used in coordinate descent
```

### Our Module Path
```
w unchanged: [1, 2, 3, 4]
... (standardization steps) ...
xv ≈ 10.0  ← Used in coordinate descent
```

## Impact on Coordinate Descent

### Soft-thresholding denominator:

**glmnet.f**:
```fortran
denom = xv(k) + vp(k)*lambda*(1-alpha)
      = 1.0 + 1.0*0.1*0.5  
      = 1.05
```

**Our module**:
```fortran
denom = xv(m) + (1-alpha)*lambda
      = 10.0 + 0.5*0.1
      = 10.05
```

**Result**: Our coefficients are ~10x smaller because the denominator is ~10x larger!

## Why This Matters

The coordinate descent update is:
```
β_new = (|gradient + xv*β_old| - λα) / (xv + λ(1-α))
```

When `xv=1` (glmnet): coefficients can grow to reasonable sizes
When `xv=10` (ours): coefficients are suppressed by factor of ~10

This explains why our coefficients are completely different!

## The Fix

To match glmnet, we must:
1. Normalize weights: `w = w/sum(w)`
2. Use `v = sqrt(w)` transform
3. Follow glmnet's exact standardization steps
4. **Set `xv = 1.0` after standardization**

Or simply use the original glmnet.f code, which does this correctly.
