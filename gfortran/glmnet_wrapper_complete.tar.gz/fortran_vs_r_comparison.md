# Comparison: Fortran Elastic Net vs R glmnet

## Key Finding: Different Results!

### Fortran Module Results (lambda=0, alpha=0)
```
Intercept:    24.04
Coefficients: [0.0, 2.18e-16, 2.98e-17] (essentially all zeros)
Predictions:  [24.04, 24.04, 24.04, 24.04] (all equal to intercept)
```

### R glmnet Results (lambda≈0, alpha=0)
```
Intercept:    11.36
Coefficients: [0.0, -6.73, 2.33]
Predictions:  [7.48, 12.14, 21.71, 35.94]
```

### R lm() Results (Weighted OLS, no regularization)
```
Intercept:    11.74
Coefficients: [NA, -6.94, 2.36]
Predictions:  [7.28, 12.13, 21.68, 35.95]
```

## Analysis

### 1. The Fortran Result (Weighted Mean)

The Fortran module with lambda=0 and alpha=0 is returning the **weighted mean** of y:
```
Weighted mean = (1×7.1 + 2×12.4 + 3×21.5 + 4×36.0) / 10 = 24.04
```

This suggests the coordinate descent algorithm in the Fortran module is:
- Setting all coefficients to zero when lambda=0 and alpha=0
- Only keeping the intercept (which becomes the weighted mean)

**Why this happens**: With no regularization (lambda=0, alpha=0) in Ridge regression, the algorithm has encountered a degenerate case or numerical issues that cause it to shrink all coefficients to zero.

### 2. The R glmnet Result (Proper Regression)

R's glmnet is fitting a **proper regression model** even with very small lambda. The predictions closely match the observed values:

| Observed y | Fortran ŷ | R glmnet ŷ | R lm ŷ   | Error (glmnet) |
|-----------|-----------|------------|----------|----------------|
| 7.10      | 24.04     | 7.48       | 7.28     | +0.38          |
| 12.40     | 24.04     | 12.14      | 12.13    | -0.26          |
| 21.50     | 24.04     | 21.71      | 21.68    | +0.21          |
| 36.00     | 24.04     | 35.94      | 35.95    | -0.06          |

### 3. Important Note: Collinearity Issue

The design matrix has **perfect collinearity**:
- Column 1: [1, 1, 1, 1] (constant)
- Column 2: [2, 3, 4, 5]
- Column 3: [4, 9, 16, 25] = Column 2 squared

When we include an intercept, the constant column is **redundant**, which is why:
- R's lm() returns `NA` for the first coefficient
- glmnet sets the first coefficient to exactly 0.0
- The model is essentially: y = β₀ + β₂·x₂ + β₃·x₃

## Why the Difference?

### Fortran Module Behavior
The Fortran elastic net implementation appears to have an issue with the lambda=0, alpha=0 case:

1. **Lambda=0** means no penalty
2. **Alpha=0** means Ridge regression (L2 penalty)
3. But **lambda=0 AND alpha=0** together means **no regularization at all**

In this degenerate case, the coordinate descent algorithm in the Fortran code converges to a trivial solution where all coefficients are zero, leaving only the intercept.

### R glmnet Behavior
R's glmnet handles this more robustly:
- Even with lambda≈0, it fits a proper regression
- It properly handles the collinearity by setting one coefficient to 0
- The predictions are very close to the true OLS solution

## Recommendations

### For the Fortran Module:

1. **Add special handling for lambda=0 case**: When lambda=0, the module should solve the OLS problem directly rather than using coordinate descent.

2. **Test with non-zero lambda**: The module is designed for regularized regression. Test with proper regularization:
   ```fortran
   fit = fit_elasticnet(x, y, w, lambda=0.1_wp, alpha=0.5_wp)
   ```

3. **Handle collinearity**: Add checks for collinear columns or perfect multicollinearity.

### Proper Use Case:
The elastic net is meant to be used with **regularization** (lambda > 0), not as a replacement for OLS regression. The test case with lambda=0, alpha=0 is testing a degenerate/edge case that isn't the intended use.

## Verification: Test with Regularization

Let's test both with proper regularization parameters:
- Lambda = 0.1 (moderate penalty)
- Alpha = 0.5 (50% L1, 50% L2 - true elastic net)

This would give us a fairer comparison of the two implementations.
